﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <set>
#include <map>
#include <string>
using namespace std;



//task1

//int main() {
//    int n, x;
//    vector<int> vec;
//    cout << "n = "; cin >> n;
//    for (int i = 0; i < n; ++i) { //начальная последовательность
//        cin >> x;
//        vec.push_back(x);
//    }
    //set<int> all_dgts; //все цифры в строке
    //for (int i = 0; i < n; ++i) {
    //    int a = vec[i];
    //    while (a > 0) { //добавляем цифры 
    //        all_dgts.insert(a % 10);
    //        a /= 10;
    //    }
    //}
//    set<int> triple_dgts; //цифры не из трехзначных
//    for (int i = 0; i < n; ++i) {
//        int a = vec[i];
//        if ((a > 0) && (a < 100)) {
//            while (a > 0) {
//                triple_dgts.insert(a % 10);
//                a /= 10;
//            }
//        }
//        if ((a > 999)) {
//            while (a > 0) {
//                triple_dgts.insert(a % 10);
//                a /= 10;
//            }
//        }
//    }
//    cout << "digits: ";
//    for (auto i : all_dgts) { //вывод
//        if (triple_dgts.count(i) == 0) {
//            cout << i << " ";
//        }
//    }
//    return 0;
//}



//task2

#include <fstream>
ifstream in1("2_2.txt");

//bool is_word(string s) {
//    for (int i = 0; i < s.length(); ++i) {
//        if (!isalpha(s[i]))
//            return false;
//    }
//    return true;
//}
//
//void Occurrence_frequency(int k) { //частота появления
//
//    string word;
//    map<string, int> period;
//
//    while (in1 >> word) { //чтение слов и цифр (что в данном задании не имеет значения)
//        if (is_word(word))
//            period[word]++;
//    }
//
//    vector<pair<int, string>> couple; //создаем пары частота слов и сами слова
//    for (auto a : period) {
//        couple.push_back(make_pair(a.second, a.first));
//    }
//
//    sort(couple.begin(), couple.end());
//
//    cout << "The least frequent " << k << " words are:\n";
//    for (int i = 0; i < k && i < couple.size(); ++i) {
//        cout << couple[i].second << "\n";
//    }
//}
//
//int main() {
//    int k;
//    cout << "Enter the value of k: ";
//    cin >> k;
//
//    Occurrence_frequency(k);
//
//    return 0;
//}



//task3

ifstream in2("2_3.txt");

//int main() {
//    string text, word;
//    char sign = ' ';
//    
//    map<string, char> words; // пары "слово - знак предложения"
//    map<string, int> words_count; // пары "слово - кол-во появлений" 
//    getline(in2, text);
//    text = ' ' + text + ' '; // костыль 
//
//    for (int i = text.length(); i >= 0; --i) { // цикл в обратном порядке чтобы начинать предложение с его знака 
//        if ((text[i] == '.') || (text[i] == '!') || (text[i] == '?')) { //если знак препинания
//            sign = text[i];
//        }
//        else if (text[i] != ' ') { //если символ
//            if (isupper(text[i])) text[i] = tolower(text[i]); // все буквы в нижний регистр
//            word += text[i];
//        }
//        else { //если пробел
//            if (words[word] != sign) words_count[word]++;
//            words[word] = sign;
//            word.erase(0, word.length()); //очищение слова
//        }
//    }
//
//    for (auto i : words) {
//        if ((i.second == '!') && (words_count[i.first] == 1)) 
//            cout << i.first << " ";
//    }
//
//    return 0;
//}



//другое неполное решение

//int main() {
//    string text, word;
//    char sign{};
//
//    map<string, int> words_count; // пары слово и кол-во появлений 
//    set<string> adda;
//    set<string> voskl;
//
//    getline(in2, text); //поток
//    text = ' ' + text;
//
//    set<int> all_words; //все слова
//
//    for (int i = text.length() - 1; i >= 0; --i) {
//        if ((text[i] == '.') || (text[i] == '!') || (text[i] == '?')) {
//            sign = text[i];
//        }
//        else if (text[i] != ' ') {
//            if (isupper(text[i])) text[i] = tolower(text[i]);
//            word = text[i] + word;
//        }
//        else if (word.length() > 0) {
//            if (sign == '.' || sign == '?') {
//                adda.insert(word);
//            }
//            else {
//                voskl.insert(word);
//            }
//            cout << word << " ";
//            word.clear();
//        }
//    }
//
//    cout << endl;
//    cout << "voskl: ";
//    for (auto i : voskl) { //вывод
//        cout << i << " ";
//    }
//
//    cout << endl;
//    cout << "adda: ";
//    for (auto i : adda) { //вывод
//        cout << i << " ";
//    }
//
//    cout << endl;
//    cout << "words: ";
//    for (auto i : voskl) { //вывод
//        if (adda.count(i) == 0) {
//            cout << i << " ";
//        }
//    }
//    cout << endl;
//
//    return 0;
//}